#include "TestPose.h"

bool testPose1() {

  return true;

}

void testPoseMain() {

  Serial.printf("testing\n");
  testPose1();

}
